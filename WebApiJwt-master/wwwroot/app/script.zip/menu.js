﻿var pages = [];
$("body").css({"opacity":0});
$(document).ready(function () {
    $.ajaxSetup({ cache: false });
    var menuEP = "/api/menu";

    var menuTemplate = "<li>"
        + "<a class=\"dropdown-toggle \" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">"
        + "<img src=\"../images/{1}.png\">" 
        + "<span style=\"font-size: 16px;letter-spacing:-0.3px;\">{0}</span> <span class=\"caret\"></span>"
        + "</a>"
        + "<ul class=\"dropdown-menu menu2\" role = \"menu\" >";
    var menuTemplateEnd =  "</ul></li>";
    var myMenuTemplate = "<li role=\"menuitem\" class= mymenu-item id=\"{0}\"><a href=\"#\" onClick=\"\"><i class=\"fa fa-user\"></i>{1}</a></li>";

    var subTemplate = "<li role=\"menuitem\"><a href=\"#\" data-url=\"{1}\"  style=\"padding:10px;\" class=\"sub-menuitem\" data-close=\"{2}\" >{0}</a></li>";
    //현재 Layout

   //카테고리 취득
    function getMenus() {

        getService(menuEP, function (data) {
            var menus = "";
            $(data).each(function (i, n) {
                menus += menuTemplate.format([n.category, i]);
                $(n.menus).each(function (j, m) {
                    menus += subTemplate.format([m.title, m.url, m.id, m.close]);
                });
                menus += menuTemplateEnd;
            });
            $(".menu").append(menus);
        
        });
    }
    //모든 페이지취득하기
    function getPages() {
       
        getService(pageEP, function (data) {
            var container = "pageContainer";
            pages = data;
            var pagesString = "";


            $(data).each(function (i, n) {
                pagesString += myMenuTemplate.format([n.id, n.title]);
            });
           
            $("#myMenu").html("").append(pagesString);
            var evt = jQuery.Event("pagesLoaded");
            $("body").trigger(evt);

        });

    }



    function bindKPI(page) {
        $(page.kpIs).each(function (i, n) {
            var cTarget = $("#chart_" + n.seq);
            var iTarget = $(cTarget).find("iframe");
            var urlMask = $(cTarget).find(".target-mask");
            var date = getDate(n.close);
            urlMask.click(function () {
                location.href = n.detailURL;
            });

            var cCode = getToken("companyCode");
            iTarget.attr("src", n.url + "&X_COMPANY=" + cCode + "&X_DATESETTING=" + date);
        });
    }

    //KPI Item 클릭
    $("body").on('click', ".sub-menuitem", (function () {
        var url = $(this).data("url");
        var date = $(this).data("close");
        var cCode = getToken("companyCode");

        url += + "&X_COMPANY=" + cCode + "&X_DATESETTING=" + date;
        location.href = "../detail.html?url=" + url;
    }));

    //회사클릭
    $("body").on('click', ".cp2Item", (function () {
        var companyCode = $(this).attr("id");
        setToken("companyCode", companyCode);

        location.href = "../index.html";
    }));

    //대시보드 아이템 클릭
    $("body").on('click', ".mymenu-item", (function () {
        var id = $(this).attr("id");
        location.href = "../index.html?dpid=" + id;
        //var page = getPageByID(Number(id));
        //newPage(page);
    }));



    
    if (getToken("role") === "1") {
        getService(companyEP, function (data) {
            var items = "";
            $(data).each(function (i, n) {
                items = items + "<li class='cp2Item ccode-"+ n.code + "' id = '" + n.code + "' > <a>" + n.companyName + "</a></li > ";
            });
            $("#companyListContainer").show();
            $("#kpiM").show();
            $("#userM").show();
            $("#companyList").append(items);
            var company = getToken("companyCode");
            var text = $(".ccode-" + company).find("a").text();
            $("#selectedCompanyTop").text(text);

        });
    }

    getMenus();
    getPages();

});

setTimeout(function () {
    $("body").animate({"opacity":1}, 300);
}, 500);