﻿$(document).ready(function () {
    
    loadHeader("../menu.html");
    var url = getParameterByName('url');
    $("#content").attr("src", url);
});

